package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.AddBookDTO;
import com.service.RegistrationService;

@Controller
public class AdminRemoveBookController {
	
	@Autowired
	private RegistrationService registrationService;
	
	@PostMapping("/adminremovebook.do")
	public ModelAndView removeBook(@RequestParam Integer book_id ) {
		
		AddBookDTO addBookDTO = new AddBookDTO();
		
		addBookDTO.setBookid(book_id);
		
		boolean removebook = registrationService.removebook(addBookDTO);
		if(removebook) {
			return new ModelAndView("admin_removebook.html");
		}else {
			return new ModelAndView("Fail.html");
		}
	}

}
