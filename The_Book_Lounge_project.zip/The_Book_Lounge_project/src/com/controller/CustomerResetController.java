package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.CustomerRegistrationDTO;
import com.service.RegistrationService;

@Controller
public class CustomerResetController {

	@Autowired
	private RegistrationService registrationService;

	@PostMapping("/resetpassword.do")
	public ModelAndView PasswordUpdate(@RequestParam String Email, @RequestParam String security_question,
			@RequestParam String answer, @RequestParam String New_Password) {

		CustomerRegistrationDTO registrationDTO = new CustomerRegistrationDTO();
		registrationDTO.setEmail(Email);
		registrationDTO.setSecurityquestions(security_question);
		registrationDTO.setAnswer(answer);
		registrationDTO.setPassword(New_Password);

		boolean update = registrationService.cusResetPassword(registrationDTO);
		if (update) {
			return new ModelAndView("success.html");
		} else {
			return new ModelAndView("Fail.html");
		}
	}

}
