package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.CustomerOrderDTO;
import com.service.RegistrationService;

@Controller
public class CustomerOrderController {

	@Autowired
	private RegistrationService registrationService;

	@PostMapping("/customerorder.do")
	public ModelAndView customerOrder(@RequestParam String Email, @RequestParam Integer book_id,
			@RequestParam String from, @RequestParam String to) {

		CustomerOrderDTO customerOrderDTO = new CustomerOrderDTO();

		customerOrderDTO.setBookid(book_id);
		customerOrderDTO.setEmail(Email);
		customerOrderDTO.setIssueDate(from);
		customerOrderDTO.setReturnDate(to);

		boolean orderplaced = registrationService.customerOrderPlaced(customerOrderDTO);
		if (orderplaced) {
			return new ModelAndView("customer_Thankyou.html");
		} else {
			return new ModelAndView("orderfail.html");
		}

	}

}
