package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.CustomerRegistrationDTO;
import com.dto.DonorRegistrationDTO;
import com.service.RegistrationService;
@Controller
public class DonorResetController {
	
	@Autowired
	private RegistrationService registrationService;

	@PostMapping("/resetdonorpassword.do")
	public ModelAndView forgetPassword(@RequestParam String Email, @RequestParam String security_questions,
			@RequestParam String answer, @RequestParam String New_Password) {

		DonorRegistrationDTO registrationDTO = new DonorRegistrationDTO();
		registrationDTO.setEmail(Email);
		registrationDTO.setSecurityquestions(security_questions);
		registrationDTO.setAnswer(answer);
		registrationDTO.setPassword(New_Password);

		boolean update = registrationService.donResetPassword(registrationDTO);
		if (update) {
			return new ModelAndView("success.html");
		} else {
			return new ModelAndView("Fail.html");
		}
	}
}
