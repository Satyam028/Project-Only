package com.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.dto.CustomerRegistrationDTO;
import com.dto.DonorRegistrationDTO;
import com.service.RegistrationService;

@Controller
public class LoginController {
	@Autowired
	public RegistrationService registrationService;
	
	//Customer Login
	
	@PostMapping("/customer_login.do")
	public ModelAndView CustomerLoginuser(@RequestParam String Email, @RequestParam String Password ) {
		 
		CustomerRegistrationDTO customerregistrationDTO = new CustomerRegistrationDTO();
		customerregistrationDTO.setEmail(Email);
		customerregistrationDTO.setPassword(Password);
		
		boolean present = registrationService.loginCustomer(customerregistrationDTO);
		if(present) {
			return new ModelAndView("customer_login_2.html");
		}else {
			return new ModelAndView("loginFail.html");
		}
	}
	
	//Donor Login
	
	@PostMapping("/donor_login.do")
	public ModelAndView DonorLoginuser(@RequestParam String Email, @RequestParam String Password ) {
		 
		DonorRegistrationDTO donorregistrationDTO = new DonorRegistrationDTO();
		donorregistrationDTO.setEmail(Email);
		donorregistrationDTO.setPassword(Password);
		
		boolean present = registrationService.loginDonor(donorregistrationDTO);
		if(present) {
			return new ModelAndView("donor_order.html");
		}else {
			return new ModelAndView("donor_loginfail.html");
		}
	}

}
