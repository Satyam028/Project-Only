package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.AddBookDAO;
import com.dao.AdminLoginDAO;
import com.dao.CustomerOrderDAO;
import com.dao.CustomerRegistrationDAO;
import com.dao.DonorOrderDAO;
import com.dao.DonorRegistrationDAO;
import com.dao.FeedbackDAO;
import com.dao.RemoveBookDAO;
import com.dto.AddBookDTO;
import com.dto.AdminDTO;
import com.dto.CustomerOrderDTO;
import com.dto.CustomerRegistrationDTO;
import com.dto.DonorOrderDTO;
import com.dto.DonorRegistrationDTO;
import com.dto.FeedbackDTO;

@Service
public class RegistrationService {
	
	@Autowired
	private CustomerRegistrationDAO customerregistrationDAO;
	
	@Autowired
	private DonorRegistrationDAO donorregistrationDAO;
	
	@Autowired
	private AdminLoginDAO adminLoginDAO; 
	
	@Autowired
	private AddBookDAO addBookDAO;
	
	@Autowired
	private FeedbackDAO feedBackDAO;
	
	@Autowired
	private com.dao.UpdatePasswordDAO UpdatePasswordDAO;
	
	@Autowired
	private DonorOrderDAO donororderDAO;
	
	@Autowired 
	private RemoveBookDAO removeBookDAO;
	
	@Autowired
	private CustomerOrderDAO customerOrderDAO;
	
	
	
	//Customer Registration 
	public boolean register(CustomerRegistrationDTO customerregistrationDTO) {
		Integer saveUser = customerregistrationDAO.saveUser(customerregistrationDTO);
		if (saveUser != null && saveUser > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	//Donor Registration 
	public boolean donorRegister(DonorRegistrationDTO donorregistrationDTO) {
			Integer saveDonorUser = donorregistrationDAO.saveDonorUser(donorregistrationDTO);
			if (saveDonorUser != null && saveDonorUser > 0) {
				return true;
			} else {
				return false;
			}
		}
		
		//Customer Login
		public boolean loginCustomer(CustomerRegistrationDTO customerregistrationDTO) {
			String Email = customerregistrationDTO.getEmail();
			String Password = customerregistrationDTO.getPassword();
			CustomerRegistrationDTO loginUser = customerregistrationDAO.loginUser(Email, Password);
			if (loginUser != null) {
				return true;
			} else {
				return false;
			}
		}
		
		//Donor Login
		public boolean loginDonor(DonorRegistrationDTO donorregistrationDTO) {
					String Email = donorregistrationDTO.getEmail();
					String Password = donorregistrationDTO.getPassword();
					DonorRegistrationDTO loginDonorUser = donorregistrationDAO.loginDonorUser(Email, Password);
					if (loginDonorUser != null) {
						return true;
					} else {
						return false;
					}
				}
		
		//Admin login
		public boolean loginAdmin(AdminDTO adminDTO) {
			String email = adminDTO.getEmailId();
			String password = adminDTO.getPassword();
			AdminDTO loginUser = adminLoginDAO.loginAdmin(email, password);
			if (loginUser != null) {
				return true;
			} else {
				return false;
			}
		}
		//AddBook in database
		public boolean booksave(AddBookDTO addBookDTO) {
			Integer saveBook = addBookDAO.saveBook(addBookDTO);
			if(saveBook!= null && saveBook > 0 ) {
				return true;
			}else {
				return false;
			}
		}
		//save feedback
		public boolean feedbacksave(FeedbackDTO feedbackDTO) {
			
			Integer feedbackSave = feedBackDAO.feedbackSave(feedbackDTO);
			if(feedbackSave!=null & feedbackSave > 0) {
				return true;
			}else {
				return false;
			}	
		}
		//Update Password
		public boolean updatePassword(CustomerRegistrationDTO registrationDTO) {
			
			String email = registrationDTO.getEmail();
			String new_password = registrationDTO.getPassword();
			
			int passwordUpdate = UpdatePasswordDAO.passwordUpdate(email, new_password);
			if(passwordUpdate>0 ) {
				return true;
			}else {
				return false;
			}
		}
		
		//DonorUpdatePassword
		public boolean updateDonorPassword(DonorRegistrationDTO registrationDTO) {
			
			String email = registrationDTO.getEmail();
			String new_password = registrationDTO.getPassword();
			
			int passwordUpdate = UpdatePasswordDAO.updateDonorPassword(email, new_password);
			if(passwordUpdate>0 ) {
				return true;
			}else {
				return false;
			}
		}
		//Customer Reset Password
			public boolean cusResetPassword(CustomerRegistrationDTO registrationDTO) {
			
			String email = registrationDTO.getEmail();
			String security_questions = registrationDTO.getSecurityquestions();
			String answers = registrationDTO.getAnswer();
			String new_passwordd = registrationDTO.getPassword();
			
			Integer passwordUpdate = UpdatePasswordDAO.cusPasswordReset(email,security_questions, answers, new_passwordd);
			if(passwordUpdate>0 && passwordUpdate != null ) {
				return true;
			}else {
				return false;
			}
		}
			
			//Donor Reset Password
			public boolean donResetPassword(DonorRegistrationDTO registrationDTO) {
			
			String email = registrationDTO.getEmail();
			String security_questions = registrationDTO.getSecurityquestions();
			String answers = registrationDTO.getAnswer();
			String new_passwordd = registrationDTO.getPassword();
			
			Integer passwordUpdate = UpdatePasswordDAO.donPasswordReset(email,security_questions, answers, new_passwordd);
			if(passwordUpdate>0 && passwordUpdate != null ) {
				return true;
			}else {
				return false;
			}
		}
			
			//Donor Order
			public boolean donorOrder(DonorOrderDTO donororderDTO) {
			Integer saveDonoOrder = donororderDAO.saveDonoOrder(donororderDTO);
			if (saveDonoOrder != null && saveDonoOrder > 0) {
				return true;
			} else {
				return false;
			}
		}
		
		//admin remove book
		public boolean removebook(AddBookDTO addBookDTO) {
			Integer bookId = addBookDTO.getBookid();
			Integer removeBook = removeBookDAO.removeBook(bookId);
			if(removeBook != null && removeBook > 0) {
				return true;
			}else {
				return false;
			}
			
		}
		
		//Reserved book for customer
				public boolean customerOrderPlaced(CustomerOrderDTO customerOrderDTO){
					Integer bookReserved = customerOrderDAO.bookReserved(customerOrderDTO);
					if(bookReserved != null && bookReserved > 0){
						return true;
					}else{
						return false;
					}
				}

		
}
