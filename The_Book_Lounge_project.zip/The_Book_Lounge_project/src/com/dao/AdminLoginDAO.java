package com.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.AdminDTO;
@Repository
public class AdminLoginDAO {
	
	@Autowired
	private SessionFactory factory;

	//Admin login
		public AdminDTO loginAdmin(String Email, String Password) {
			AdminDTO adminDTO = null;
			String hql = "select admin from AdminDTO admin where admin.emailId=:name1 and admin.password=:name2";
			try (Session session = factory.openSession()) {
				Query query = session.createQuery(hql);
				query.setParameter("name1", Email);
				query.setParameter("name2", Password);
				adminDTO = (AdminDTO) query.uniqueResult();
			} catch (HibernateException e) {
				e.printStackTrace();
			}
			return adminDTO;
		}
}
