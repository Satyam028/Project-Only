package com.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dto.CustomerRegistrationDTO;
import com.dto.DonorRegistrationDTO;

@Repository
public class DonorRegistrationDAO {
	
	@Autowired
	private SessionFactory factory;
	
	//Registration
	public Integer saveDonorUser(DonorRegistrationDTO donorregistrationDTO) {
		Transaction transaction = null;
		Integer userRegistered = null;
		
		try (Session session = factory.openSession()) {
			transaction = session.beginTransaction();
			userRegistered = (Integer) session.save(donorregistrationDTO);
			transaction.commit();
		} catch (HibernateException e) {
			e.printStackTrace();
			transaction.rollback();
		}
		return userRegistered;
	}
	
	//Donor Login 
	public DonorRegistrationDTO loginDonorUser(String Email, String Password) {
		DonorRegistrationDTO donorregistrationDTO = null;
		String hql = "select donor from DonorRegistrationDTO donor where donor.Email=:name1 and donor.Password=:name2";
		try (Session session = factory.openSession()) {
			Query query = session.createQuery(hql);
			query.setParameter("name1", Email);
			query.setParameter("name2", Password);
			donorregistrationDTO = (DonorRegistrationDTO) query.uniqueResult();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return donorregistrationDTO;
	}

}
