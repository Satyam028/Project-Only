package com.dao;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class UpdatePasswordDAO {
	@Autowired
	private SessionFactory factory;
	
	//password update using email and phone no
		public int passwordUpdate(String email, String new_password) {
			int NoOfRecordUpdate = 0;
			Transaction transaction = null;
			String hql = "update CustomerRegistrationDTO register set register.Password=:name1 where register.Email =:name2";
			try (Session session = factory.openSession()) {
				transaction = session.beginTransaction();
				Query query = session.createQuery(hql);
				query.setParameter("name1", new_password);
				query.setParameter("name2", email);
				NoOfRecordUpdate = query.executeUpdate();
				transaction.commit();
			} catch (HibernateException e) {
				e.printStackTrace();
				transaction.rollback();
			}
			
			return NoOfRecordUpdate;
		}
		
		//Donor update 
		//password update using email and phone no
				public int updateDonorPassword(String email, String new_password) {
					int NoOfRecordUpdate = 0;
					Transaction transaction = null;
					String hql = "update DonorRegistrationDTO register set register.Password=:name1 where register.Email =:name2";
					try (Session session = factory.openSession()) {
						transaction = session.beginTransaction();
						Query query = session.createQuery(hql);
						query.setParameter("name1", new_password);
						query.setParameter("name2", email);
						NoOfRecordUpdate = query.executeUpdate();
						transaction.commit();
					} catch (HibernateException e) {
						e.printStackTrace();
						transaction.rollback();
					}
					
					return NoOfRecordUpdate;
				}
				
	//Customer password reset
				public int cusPasswordReset(String email, String security_questions, String answers,String new_passwordd) {
					Integer NoOfRecordUpdate = null;
					Transaction transaction = null;
					String hql = "update CustomerRegistrationDTO register set register.Password=:name1 where register.Email =:name2 and register.securityquestions=:name3 and register.answer=:name4";
					try (Session session = factory.openSession()) {
						transaction = session.beginTransaction();
						Query query = session.createQuery(hql);
						
						query.setParameter("name2", email);
						query.setParameter("name3", security_questions);
						query.setParameter("name4", answers);
						query.setParameter("name1", new_passwordd);
						
						NoOfRecordUpdate = (Integer) query.executeUpdate();
						transaction.commit();
					} catch (HibernateException e) {
						e.printStackTrace();
						transaction.rollback();
					}
					
					return NoOfRecordUpdate;
				}
				
				//Donor password reset
				public Integer donPasswordReset(String email, String security_questions, String answers,String new_password) {
					Integer NoOfRecordUpdate = null;
					Transaction transaction = null;
					String hql = "update DonorRegistrationDTO register set register.Password=:name1 where register.Email =:name2 and register.securityquestions=:name3 and register.answer=:name4";
					try (Session session = factory.openSession()) {
						transaction = session.beginTransaction();
						Query query = session.createQuery(hql);
						
						query.setParameter("name2", email);
						query.setParameter("name3", security_questions);
						query.setParameter("name4", answers);
						query.setParameter("name1", new_password);
						
						NoOfRecordUpdate = (Integer) query.executeUpdate();
						transaction.commit();
					} catch (HibernateException e) {
						e.printStackTrace();
						transaction.rollback();
					}
					
					return NoOfRecordUpdate;
				}
		
	}
