package com.dto;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;


@Entity
@Table(name = "Add_Book_TABLE")
public class AddBookDTO implements Serializable {
	
	@Id
	@GenericGenerator(name="auto", strategy="increment")
	@GeneratedValue(generator = "auto")
	@Column(name = "book_id")
	private int bookid;

	@Column(name = "book_name")
	private String bookname;

	@Column(name = "author_name")
	private String authorname;

	@Column(name = "book_type")
	private String booktype;

	@Column(name = "book_edition")
	private String bookedition;

	public AddBookDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
		
	}

	public int getBookid() {
		return bookid;
	}

	public void setBookid(Integer bookid) {
		this.bookid = bookid;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public String getAuthorname() {
		return authorname;
	}

	public void setAuthorname(String authorname) {
		this.authorname = authorname;
	}

	public String getBooktype() {
		return booktype;
	}

	public void setBooktype(String booktype) {
		this.booktype = booktype;
	}

	public String getBookedition() {
		return bookedition;
	}

	public void setBookedition(String bookedition) {
		this.bookedition = bookedition;
	}
	

}
