package com.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="TBL_DONOR_DETAILS")
public class DonorRegistrationDTO {
	
	
	@Id
	@GenericGenerator(name="auto", strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="user_number")
	private int userNumber;
	
	@Column(name="Name")
	private String name;
	
	@Column(name="Phone_Number")
	private Long Mobile_number;
	
	@Column(name="Email")
	private String Email;
	
	@Column(name="Password")
	private String Password;
	
	@Column(name="Address")
	private String Address;
	
	@Column(name="Security_Questions")
	private String securityquestions;
	
	@Column(name="Security_Answer")
	private String answer;
	
	
	
	public DonorRegistrationDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}



	public int getUserNumber() {
		return userNumber;
	}



	public void setUserNumber(int userNumber) {
		this.userNumber = userNumber;
	}



	public String getName() {
		return name;
	}



	public void setName(String name) {
		this.name = name;
	}



	public Long getMobile_number() {
		return Mobile_number;
	}



	public void setMobile_number(Long mobile_number) {
		Mobile_number = mobile_number;
	}



	public String getEmail() {
		return Email;
	}



	public void setEmail(String email) {
		Email = email;
	}



	public String getPassword() {
		return Password;
	}



	public void setPassword(String password) {
		Password = password;
	}



	public String getAddress() {
		return Address;
	}



	public void setAddress(String address) {
		Address = address;
	}



	public String getSecurityquestions() {
		return securityquestions;
	}



	public void setSecurityquestions(String securityquestions) {
		this.securityquestions = securityquestions;
	}



	public String getAnswer() {
		return answer;
	}



	public void setAnswer(String answer) {
		this.answer = answer;
	}

}
