package com.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Entity
@Table(name="TBL_DONOR_ORDER_DETAILS")
public class DonorOrderDTO {
	
	@Id
	@GenericGenerator(name="auto", strategy="increment")
	@GeneratedValue(generator="auto")
	@Column(name="user_number")
	private int userNumber;
	
	@Column(name="Email")
	private String Email;
	
	@Column(name="BookName")
	private String bookname;
	
	@Column(name="AuthorName")
	private String authorname;
	
	@Column(name="Booktype")
	private String booktype;
	
	@Column(name="PickupDate")
	private String pickupdate;
	
	@Column(name="PickupAddress")
	private String pickupaddress;
	
	
	
	public DonorOrderDTO() {
		System.out.println(this.getClass().getSimpleName() + " object created");
	}

	public int getUserNumber() {
		return userNumber;
	}

	public void setUserNumber(int userNumber) {
		this.userNumber = userNumber;
	}

	public String getBookname() {
		return bookname;
	}

	public void setBookname(String bookname) {
		this.bookname = bookname;
	}

	public String getAuthorname() {
		return authorname;
	}

	public void setAuthorname(String author_name) {
		this.authorname = author_name;
	}

	public String getBooktype() {
		return booktype;
	}

	public void setBooktype(String booktype) {
		this.booktype = booktype;
	}

	public String getPickupdate() {
		return pickupdate;
	}

	public void setPickupdate(String pickupdate) {
		this.pickupdate = pickupdate;
	}

	public String getPickupaddress() {
		return pickupaddress;
	}

	public void setPickupaddress(String pickupaddress) {
		this.pickupaddress = pickupaddress;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String Email) {
		this.Email = Email;
	}

	

	
		
		
	}

	


		
	
	


